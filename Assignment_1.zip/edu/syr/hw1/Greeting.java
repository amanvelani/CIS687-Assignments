package edu.syr.hw1;

public class Greeting {
    public void greet(){
        System.out.println("Hello World");
    }
}
